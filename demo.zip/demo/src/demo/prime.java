package demo;
import java.util.*;

public class prime {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("enter number: ");
		int n=sc.nextInt(),i=1,count=0;
		while(i<=n) {
			if(n%i==0)count++;
			i++;
		}
		if(count==2)System.out.println(n+" is prime");
		else System.out.println(n+" is not prime");
		sc.close();
	}

}
