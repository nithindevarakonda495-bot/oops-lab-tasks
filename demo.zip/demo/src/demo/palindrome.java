package demo;
import java.util.*;
public class palindrome {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number");
		int n=sc.nextInt(),rev =0,temp=n;
		while(n>0) {
			rev = rev*10 + n%10;
			n=n/10;
		}
		if(temp==rev) 
			System.out.println(temp+" is palindrome");
		else System.out.println(" is not palindrome");
		sc.close();
	}

}
