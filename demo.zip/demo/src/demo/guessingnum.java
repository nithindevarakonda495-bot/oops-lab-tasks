package demo;
import java.util.*;

public class guessingnum {
	public static void main(String[]args) {
		try (var sc = new Scanner(System.in)) {
			int s= 7, a=1;
			while(a<=3) {
				System.out.print("Attempt "+a+" Guess");
				int guess= sc.nextInt();
				if(guess==s) {
					System.out.println("Correct! you won");
					return;
				}else {
					System.out.println("Wrong");
				}
				a++;
			}
			System.out.println("Game Over! Secret was"+s);
			sc.close();
		}
	}

}
