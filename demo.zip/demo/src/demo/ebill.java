package demo;
import java.util.*;

public class ebill {
	public static void main(String[]args) {
		int[] units = {100,150,200,120,180,90};
		int rate =7;
		int total=0;
		for(int i=0;i<6;i++) {
			int bill =units[i]*rate;
			System.out.println("month"+(i+1)+" bill="+bill);
			total+=bill;
		}
		System.out.println("total 6 months bill="+total);
		
	}

}
