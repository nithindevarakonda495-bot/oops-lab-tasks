package demo;
import java.util.*;
public class largestele {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		int n = sc.nextInt();
		int a[]= new int[n];
		for(int i=0;i<n;i++)a[i]=sc.nextInt();
		int max=a[0];
		for(int x:a)
			if(x>max) max =x;
		System.out.println("largest = "+ max);
		sc.close();
	}

}
