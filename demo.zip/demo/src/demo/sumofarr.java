package demo;
import java.util.*;
public class sumofarr {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter size:");
		int n=sc.nextInt();
		int a[]= new int[n];
		int sum =0;
		System.out.println("Enter"+n+"elements");
		for(int i=0;i<n;i++)a[i]=sc.nextInt();
		for(int x:a)sum +=x;
		System.out.println("sum = "+sum);
		sc.close();
	}

}
