package constructor;
import java.util.*;
public class code1 {  
    String name;
    int age;
    String dept;

    code1() {
        System.out.println("Default Constructor Called");
        name = "Unknown";
        age = 0;
    }

    code1(String name, int age, String dept) {
        System.out.println("Parameterized Constructor Called");
        this.name = name;
        this.age = age;
        this.dept = dept;
    }

    void display() {
        System.out.println("Name: " + this.name + ", Age: " + this.age + ", Dept: " + this.dept);
    }

    public static void main(String[] args) {
        code1 s1 = new code1();
        s1.display();
        code1 s2 = new code1("Rahul", 20, "CSE");
        s2.display();
    }
}