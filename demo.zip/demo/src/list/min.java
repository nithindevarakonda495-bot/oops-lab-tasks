package list;

	import java.util.*;

	class Player {
	    String name;
	    int score;

	    Player(String name, int score) {
	        this.name = name;
	        this.score = score;
	    }

	    public String toString() {
	        return "Name: " + name + ", Score: " + score;
	    }
	}

	public class min {
	    public static void main(String[] args) {

	        Map<Integer, Player> players = new HashMap<>();

	        
	        players.put(101, new Player("Dhoni", 100));
	        players.put(102, new Player("Kohli", 80));
	        players.put(103, new Player("Dhoni", 80));
	        players.put(104, new Player("Rohit", 95));
	        players.put(105, new Player("Kohli", 110));

	        
	        System.out.println("----- All Player Details -----");
	        for (Map.Entry<Integer, Player> entry : players.entrySet()) {
	            System.out.println("Player ID: " + entry.getKey());
	            System.out.println(entry.getValue());
	            System.out.println();
	        }

	        
	        int searchId = 103;
	        System.out.println("----- Search By Player ID -----");
	        if (players.containsKey(searchId)) {
	            System.out.println("Player ID exists!");
	            System.out.println("Player Details: " + players.get(searchId));
	        } else {
	            System.out.println("Player ID does not exist!");
	        }

	        String searchName = "kohli";
	        System.out.println("\n----- Search By Player Name -----");
	        boolean found = false;
	        for (Map.Entry<Integer, Player> entry : players.entrySet()) {
	            if (entry.getValue().name.equalsIgnoreCase(searchName)) {
	                System.out.println("Player Found!");
	                System.out.println("Player ID: " + entry.getKey());
	                System.out.println("Player Name: " + entry.getValue().name);
	                System.out.println("Player Score: " + entry.getValue().score);
	                found = true;
	            }
	        }
	        if (!found) {
	            System.out.println("Player not found!");
	        }
	    }
	}


