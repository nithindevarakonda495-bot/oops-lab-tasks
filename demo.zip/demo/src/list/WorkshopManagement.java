package list;
import java.util.*;

	class Workshop {
	    int id;
	    String customerName;
	    String workType;

	    Workshop(int id, String customerName, String workType) {
	        this.id = id;
	        this.customerName = customerName;
	        this.workType = workType;
	    }

	    void display() {
	        System.out.println(id + " | " + customerName + " | " + workType);
	    }
	}

	public class WorkshopManagement {
	    public static void main(String[] args) {

	        ArrayList<Workshop> list = new ArrayList<>();
	        Scanner sc = new Scanner(System.in);
	        int choice;

	        do {
	            System.out.println("\n===== WORKSHOP MENU =====");
	            System.out.println("1. Add Work");
	            System.out.println("2. View Works");
	            System.out.println("3. Update Work");
	            System.out.println("4. Delete Work");
	            System.out.println("5. Exit");
	            System.out.print("Enter your choice: ");
	            choice = sc.nextInt();

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter Work ID: ");
	                    int id = sc.nextInt();
	                    sc.nextLine();
	                    System.out.print("Enter Customer Name: ");
	                    String name = sc.nextLine();
	                    System.out.print("Enter Work Type: ");
	                    String work = sc.nextLine();
	                    list.add(new Workshop(id, name, work));
	                    System.out.println("Work Added Successfully!");
	                    break;

	                case 2:
	                    if (list.isEmpty()) {
	                        System.out.println("No Works Found!");
	                    } else {
	                        System.out.println("\nWorkshop List:");
	                        for (Workshop w : list) {
	                            w.display();
	                        }
	                    }
	                    break;

	                case 3:
	                    System.out.print("Enter Work ID to Update: ");
	                    int updateId = sc.nextInt();
	                    sc.nextLine();
	                    boolean updated = false;
	                    for (Workshop w : list) {
	                        if (w.id == updateId) {
	                            System.out.print("Enter New Customer Name: ");
	                            w.customerName = sc.nextLine();
	                            System.out.print("Enter New Work Type: ");
	                            w.workType = sc.nextLine();
	                            updated = true;
	                            System.out.println("Work Updated Successfully!");
	                            break;
	                        }
	                    }
	                    if (!updated) System.out.println("Work ID Not Found!");
	                    break;

	                case 4:
	                    System.out.print("Enter Work ID to Delete: ");
	                    int deleteId = sc.nextInt();
	                    boolean deleted = false;
	                    for (Workshop w : list) {
	                        if (w.id == deleteId) {
	                            list.remove(w);
	                            deleted = true;
	                            System.out.println("Work Deleted Successfully!");
	                            break;
	                        }
	                    }
	                    if (!deleted) System.out.println("Work ID Not Found!");
	                    break;

	                case 5:
	                    System.out.println("Program Exited.");
	                    break;

	                default:
	                    System.out.println("Invalid Choice!");
	            }
	        } while (choice != 5);

	        sc.close();
	    }
	}


