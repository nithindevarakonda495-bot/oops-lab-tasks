package oops;

interface CabBooking {
    void bookRide();
    double calculateFare();
}

interface PaymentGateway {
    void pay(double amount);
}

class CustomerBase {
    private String customerName;
    private double distance;
    public CustomerBase(String name, double d) {
        this.customerName = name;
        this.distance = d;
    }
    public String getCustomerName() { return customerName; }
    public double getDistance() { return distance; }
}

class MiniCab extends CustomerBase implements CabBooking, PaymentGateway {
    public MiniCab(String name, double d) { super(name, d); }
    public void bookRide() {
        System.out.println("MiniCab booked for " + getCustomerName());
    }
    public double calculateFare() {
        return getDistance() * 10;
    }
    public void pay(double amount) {
        System.out.println("Payment Rs." + amount + " Done via Cash");
    }
}

class AutoCab extends CustomerBase implements CabBooking, PaymentGateway {
    public AutoCab(String name, double d) { super(name, d); }
    public void bookRide() {
        System.out.println("AutoCab booked for " + getCustomerName());
    }
    public double calculateFare() {
        return getDistance() * 8;
    }
    public void pay(double amount) {
        System.out.println("Payment Rs." + amount + " Done via UPI");
    }
}

public class CabBookingSystem {
    public static void main(String[] args) {
        MiniCab m = new MiniCab("Nithin", 5);
        m.bookRide();
        double fare = m.calculateFare();
        System.out.println("Fare: " + fare);
        m.pay(fare);
        System.out.println("------------------");
        AutoCab a = new AutoCab("Ramesh", 10);
        a.bookRide();
        double fare2 = a.calculateFare();
        System.out.println("Fare: " + fare2);
        a.pay(fare2);
    }
}