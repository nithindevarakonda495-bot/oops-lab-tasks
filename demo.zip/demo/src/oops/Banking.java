package oops;

public class Banking {

	    void deposit(int amount) {
	        System.out.println("Deposited Cash: " + amount);
	    }

	    void deposit(int amount, String chequeNo) {
	        System.out.println("Deposited " + amount + " via Cheque: " + chequeNo);
	    }

	    void deposit(int amount, String upiId, String bankName) {
	        System.out.println("Deposited " + amount + " via UPI: " + upiId + " Bank: " + bankName);
	    }

	    public static void main(String[] args) {
	        Banking b = new Banking();
	        b.deposit(50000);
	        b.deposit(10000, "CHQ12345");
	        b.deposit(20000, "Nithin@upi", "SBI");
	    }
	}


