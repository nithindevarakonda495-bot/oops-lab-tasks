package oops;

public class BasicLogin {

	    void login(String username, String password) {
	        System.out.println("Login with Username: " + username);
	    }

	    void login(int id, String password) {
	        System.out.println("Login with ID: " + id);
	    }

	    void login(long mobileno, String password) {
	        System.out.println("Login with Mobile: " + mobileno);
	    }

	    public static void main(String[] args) {
	        BasicLogin obj = new BasicLogin();
	        obj.login("Nithin", "Nithin123");
	        obj.login(101, "pass123");
	        obj.login(9876543210L, "mobilePass");
	    }
	}


