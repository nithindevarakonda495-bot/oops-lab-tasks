package oops;
import java.util.*;

	// Parent class
	class Product {
	    int product_id;
	    String product_name;
	    double price;

	    void setProduct(int id, String name, double price) {
	        this.product_id = id;
	        this.product_name = name;
	        this.price = price;
	    }

	    void displayProduct() {
	        System.out.println("Product ID: " + product_id + " | Name: " + product_name + " | Price: " + price);
	    }
	}

	// Child 1
	class Electronics extends Product {
	    int warranty;
	    void showElectronics(int warranty) {
	        displayProduct();
	        System.out.println("Category: Electronics | Warranty: " + warranty + " years");
	    }
	}

	// Child 2
	class Clothing extends Product {
	    String size;
	    void showClothing(String size) {
	        displayProduct();
	        System.out.println("Category: Clothing | Size: " + size);
	    }
	}

	// Child 3
	class Food extends Product {
	    String expiry;
	    void showFood(String expiry) {
	        displayProduct();
	        System.out.println("Category: Food | Expiry Date: " + expiry);
	    }
	}

	public class OnlineShopping {
	    public static void main(String[] args) {
	        Electronics e = new Electronics();
	        e.setProduct(1, "Laptop", 55000);
	        e.showElectronics(2);

	        System.out.println("--------------------------------");

	        Clothing c = new Clothing();
	        c.setProduct(2, "T-Shirt", 999);
	        c.showClothing("XL");

	        System.out.println("--------------------------------");

	        Food f = new Food();
	        f.setProduct(3, "Milk", 60);
	        f.showFood("10-Jan-2026");
	    }
	}


