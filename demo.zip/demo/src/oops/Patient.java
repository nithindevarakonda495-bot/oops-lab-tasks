package oops;

	public class Patient {
	    // private - encapsulation
	    private int patientId;
	    private String patientName;
	    private String disease;
	    private double bill;

	    // Getter
	    public int getPatientId() {
	        return patientId;
	    }
	    public String getPatientName() {
	        return patientName;
	    }
	    public String getDisease() {
	        return disease;
	    }
	    public double getBill() {
	        return bill;
	    }

	    // Setter
	    public void setPatientId(int patientId) {
	        this.patientId = patientId;
	    }
	    public void setPatientName(String patientName) {
	        this.patientName = patientName;
	    }
	    public void setDisease(String disease) {
	        this.disease = disease;
	    }
	    public void setBill(double bill) {
	        if (bill >= 0) {
	            this.bill = bill;
	        } else {
	            System.out.println("Bill cannot be negative");
	        }
	    }

	    
	    public static void main(String[] args) {
	        Patient p1 = new Patient();
	        
	        // Setter
	        p1.setPatientId(101);
	        p1.setPatientName("Ramesh");
	        p1.setDisease("Fever");
	        p1.setBill(2000);

	        // Getter 
	        System.out.println("ID: " + p1.getPatientId());
	        System.out.println("Name: " + p1.getPatientName());
	        System.out.println("Disease: " + p1.getDisease());
	        System.out.println("Bill: " + p1.getBill());
	    }
	}


