package oops;

public class CarRent{

	    void rentCar(int hrs) {
	        System.out.println("Rented for Hours: " + hrs + " hrs, Charge: " + (hrs * 100));
	    }
	    
	    void rentCar(boolean isDaily, int days) {
	        if(isDaily) {
	            System.out.println("Rented for Days: " + days + " days, Charge: " + (days * 2000));
	        }
	    }
	    
	    void rentCar(int days, int amount, boolean isDriver) {
	        if(isDriver) {
	            System.out.println("Rented for " + days + " days with Driver, Total: " + (amount + 500) + " (Driver charge extra)");
	        } else {
	            System.out.println("Rented for " + days + " days without Driver, Total: " + amount);
	        }
	    }

	    public static void main(String[] args) {
	        CarRent obj = new CarRent();
	        obj.rentCar(5);
	        obj.rentCar(true, 3);
	        obj.rentCar(3, 6000, true);
	    }
	}


