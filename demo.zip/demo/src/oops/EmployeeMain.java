package oops;

	class Employee {
	    int empid;
	    String empname;
	    double basic_salary;

	    void setEmployee(int id, String name, double salary) {
	        empid = id;
	        empname = name;
	        basic_salary = salary;
	    }

	    void displayEmployee() {
	        System.out.println("ID: " + empid + " | Name: " + empname + " | Salary: " + basic_salary);
	    }
	}

	class Manager extends Employee {
	    void showManager(int bonus) {
	        displayEmployee();
	        System.out.println("Role: Manager, Bonus: " + bonus + ", Total: " + (basic_salary + bonus));
	    }
	}

	class Developer extends Employee {
	    void showDeveloper(int extra) {
	        displayEmployee();
	        System.out.println("Role: Developer, Extra: " + extra + ", Total: " + (basic_salary + extra));
	    }
	}

	class Intern extends Employee {
	    void showIntern() {
	        displayEmployee();
	        System.out.println("Role: Intern");
	    }
	}

	public class EmployeeMain {
	    public static void main(String[] args) {
	        Manager m = new Manager();
	        m.setEmployee(101, "Amit", 50000);
	        m.showManager(10000);
	        System.out.println("-------------------");
	        Developer d = new Developer();
	        d.setEmployee(102, "Priya", 40000);
	        d.showDeveloper(5000);
	        System.out.println("-------------------");
	        Intern i = new Intern();
	        i.setEmployee(103, "Rahul", 15000);
	        i.showIntern();
	    }
	}


