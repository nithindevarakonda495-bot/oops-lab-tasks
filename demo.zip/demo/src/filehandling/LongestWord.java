package filehandling;

	import java.io.BufferedReader;
	import java.io.FileReader;
	import java.io.IOException;

	public class LongestWord {
	    public static void main(String[] args) {
	        String longestWord = "";
	        try {
	            BufferedReader br = new BufferedReader(new FileReader("src/filehandling/input.txt"));
	            String line;
	            while ((line = br.readLine()) != null) {
	                String[] words = line.split(" ");
	                for (String word : words) {
	                    if (word.length() > longestWord.length()) {
	                        longestWord = word;
	                    }
	                }
	            }
	            br.close();
	            System.out.println("Longest Word: " + longestWord);
	        } catch (IOException e) {
	            System.out.println("Error reading file");
	        }
	    }
	}


