package filehandling;

	import java.io.FileWriter;
	import java.io.IOException;
	import java.util.Scanner;

	public class AppendData {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        try {
	            FileWriter writer = new FileWriter("employees.txt", true);
	            System.out.print("Enter employee data to append: ");
	            String data = sc.nextLine();
	            writer.write(data + "\n");
	            writer.close();
	            System.out.println("Data appended to employees.txt");
	        } catch (IOException e) {
	            System.out.println("Error appending");
	        }
	        sc.close();
	    }
	}


