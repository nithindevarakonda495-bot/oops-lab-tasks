package filehandling;

	import java.io.BufferedReader;
	import java.io.FileReader;
	import java.io.IOException;

	public class StudentMarks {
	    public static void main(String[] args) {
	        int highest = 0, lowest = 100, total = 0, count = 0, above80 = 0;
	        String highestName = "", lowestName = "";
	        try {
	            BufferedReader br = new BufferedReader(new FileReader("src/filehandling/students.txt"));
	            String line;
	            while ((line = br.readLine()) != null) {
	                String[] data = line.split(",");
	                String name = data[1];
	                int marks = Integer.parseInt(data[2].trim());
	                total += marks;
	                count++;
	                if (marks > highest) { highest = marks; highestName = name; }
	                if (marks < lowest) { lowest = marks; lowestName = name; }
	                if (marks > 80) above80++;
	            }
	            br.close();
	            double average = (double) total / count;
	            System.out.println("Highest: " + highestName + " - " + highest);
	            System.out.println("Lowest: " + lowestName + " - " + lowest);
	            System.out.println("Average: " + average);
	            System.out.println("Above 80: " + above80);
	        } catch (IOException e) {
	            System.out.println("Error: " + e.getMessage());
	        }
	    }
	}


