package filehandling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class EvenOddSeperate {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("src/filehandling/numbers.txt"));
            BufferedWriter evenWriter = new BufferedWriter(new FileWriter("src/filehandling/even.txt"));
            BufferedWriter oddWriter = new BufferedWriter(new FileWriter("src/filehandling/odd.txt"));

            String line;
            while ((line = br.readLine()) != null) {
                int num = Integer.parseInt(line.trim());
                if (num % 2 == 0) {
                    evenWriter.write(String.valueOf(num));
                    evenWriter.newLine();
                } else {
                    oddWriter.write(String.valueOf(num));
                    oddWriter.newLine();
                }
            }
            br.close();
            evenWriter.close();
            oddWriter.close();
            
            System.out.println("Separation completed!");

        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
    }
}