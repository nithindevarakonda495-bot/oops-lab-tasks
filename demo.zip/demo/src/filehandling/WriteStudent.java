package filehandling;

import java.io.FileWriter;
import java.util.Scanner;

public class WriteStudent {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            FileWriter writer = new FileWriter("src/filehandling/students.txt", true);
            
            System.out.print("Enter Student ID: ");
            String id = sc.nextLine();
            System.out.print("Enter Name: ");
            String name = sc.nextLine();
            System.out.print("Enter Course: ");
            String course = sc.nextLine();
            System.out.print("Enter Marks: ");
            String marks = sc.nextLine();

            writer.write(id + "," + name + "," + marks + "\n");
            writer.close();
            
            System.out.println("Data written successfully!");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        sc.close();
    }
}