package filehandling;

	import java.io.File;
	import java.io.IOException;
	import java.util.Scanner;

	public class CreateCheckFile {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter file name: ");
	        String fileName = sc.nextLine();
	        File file = new File(fileName);
	        try {
	            if (file.createNewFile()) {
	                System.out.println("File Created: " + file.getName());
	            } else {
	                System.out.println("File already exists");
	            }
	            System.out.println("Path: " + file.getAbsolutePath());
	            System.out.println("Can Read: " + file.canRead());
	            System.out.println("Can Write: " + file.canWrite());
	            System.out.println("Length: " + file.length());
	        } catch (IOException e) {
	            System.out.println("Error creating file");
	        }
	        sc.close();
	    }
	}


