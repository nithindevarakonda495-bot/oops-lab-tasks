package filehandling;

	import java.io.BufferedReader;
	import java.io.FileReader;
	import java.io.IOException;
	import java.util.Scanner;

	public class SearchWord {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter word to search: ");
	        String searchWord = sc.nextLine();
	        int count = 0;
	        try {
	            BufferedReader br = new BufferedReader(new FileReader("src/filehandling/input.txt"));
	            String line;
	            while ((line = br.readLine()) != null) {
	                String[] words = line.split(" ");
	                for (String word : words) {
	                    if (word.equalsIgnoreCase(searchWord)) {
	                        count++;
	                    }
	                }
	            }
	            br.close();
	            System.out.println("Word '" + searchWord + "' found " + count + " times");
	        } catch (IOException e) {
	            System.out.println("File not found");
	        }
	        sc.close();
	    }
	}


