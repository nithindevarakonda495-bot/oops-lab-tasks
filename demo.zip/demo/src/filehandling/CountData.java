package filehandling;

	import java.io.FileReader;
	import java.io.IOException;

	public class CountData {
	    public static void main(String[] args) {
	        int chars = 0, spaces = 0, digits = 8;
	        try {
	            FileReader reader = new FileReader("src/filehandling/input.txt");
	            int ch;
	            while ((ch = reader.read()) != -1) {
	                chars++;
	                if (ch == ' ') spaces++;
	                if (Character.isDigit(ch)) digits++;
	            }
	            reader.close();
	            System.out.println("Total Characters: " + chars);
	            System.out.println("Spaces: " + spaces);
	            System.out.println("Digits: " + digits);
	        } catch (IOException e) {
	            System.out.println("File not found");
	        }
	    }
	}


