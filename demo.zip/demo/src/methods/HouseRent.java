package methods;
import java.util.*;
public class HouseRent {
	    static Scanner sc = new Scanner(System.in);
	    
	    static double calculateRent(String type, int months) {
	        double rentPerMonth = 0;
	        if (type.equalsIgnoreCase("1BHK")) {
	            rentPerMonth = 8000;
	        } else if (type.equalsIgnoreCase("2BHK")) {
	            rentPerMonth = 12000;
	        } else if (type.equalsIgnoreCase("lease house")) {
	            rentPerMonth = 15000;
	        } else {
	            System.out.println("Invalid house type");
	            return 0;
	        }
	        return rentPerMonth * months;
	    }

	    public static void main(String[] args) {
	        System.out.print("Enter owner name: ");
	        String owner = sc.nextLine();
	        
	        System.out.print("Enter house type (1BHK / 2BHK / lease house): ");
	        String type = sc.nextLine();

	        System.out.print("Enter number of months: ");
	        int months = sc.nextInt();

	        double totalRent = calculateRent(type, months);

	        System.out.println("\n===== RENT RECEIPT =====");
	        System.out.println("Owner: " + owner);
	        System.out.println("House Type: " + type);
	        System.out.println("Months: " + months);
	        System.out.println("Total Rent: Rs. " + totalRent);
	    }
	}


