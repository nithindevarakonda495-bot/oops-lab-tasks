package methods;
import java.util.*;
public class Atmprogram {
	    static double balance = 10000; // initial balance
	    static Scanner sc = new Scanner(System.in);

	    // Method 1 - Check Balance
	    static void checkBalance() {
	        System.out.println("Your Current Balance is: Rs. " + balance);
	    }

	    // Method 2 - Deposit
	    static void deposit() {
	        System.out.print("Enter amount to deposit: ");
	        double amt = sc.nextDouble();
	        if (amt > 0) {
	            balance += amt;
	            System.out.println("Rs. " + amt + " Deposited Successfully");
	        } else {
	            System.out.println("Invalid Amount");
	        }
	    }

	    // Method 3 - Withdraw
	    static void withdraw() {
	        System.out.print("Enter amount to withdraw: ");
	        double amt = sc.nextDouble();
	        if (amt > 0 && amt <= balance) {
	            balance -= amt;
	            System.out.println("Rs. " + amt + " Withdrawn Successfully");
	        } else {
	            System.out.println("Insufficient Balance or Invalid Amount");
	        }
	    }

	    public static void main(String[] args) {
	        int choice;
	        do {
	            System.out.println("\n===== ATM MENU =====");
	            System.out.println("1. Check Balance");
	            System.out.println("2. Deposit");
	            System.out.println("3. Withdraw");
	            System.out.println("4. Exit");
	            System.out.print("Enter your choice: ");
	            choice = sc.nextInt();

	            switch (choice) {
	                case 1:
	                    checkBalance();
	                    break;
	                case 2:
	                    deposit();
	                    break;
	                case 3:
	                    withdraw();
	                    break;
	                case 4:
	                    System.out.println("Thank you for using ATM. Exit.");
	                    break;
	                default:
	                    System.out.println("Invalid Choice! Try Again");
	            }
	        } while (choice != 4);
	    }
	}


