package methods;
import java.util.*;
public class Temparaturereading {
	
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter number of patients: ");
	        int patients = sc.nextInt();
	        System.out.print("Enter number of days/readings: ");
	        int days = sc.nextInt();
	        sc.nextLine();

	        String[] names = new String[patients];
	        double[][] temp = new double[patients][days]; // 2D array

	        for (int i = 0; i < patients; i++) {
	            System.out.print("\nEnter name of patient " + (i+1) + ": ");
	            names[i] = sc.nextLine();
	            for (int j = 0; j < days; j++) {
	                System.out.print("Enter temp for Day " + (j+1) + ": ");
	                temp[i][j] = sc.nextDouble();
	            }
	            sc.nextLine();
	        }

	        
	        System.out.println("\n===== REPORT =====");
	        for (int i = 0; i < patients; i++) {
	            System.out.print(names[i] + " -> ");
	            for (int j = 0; j < days; j++) {
	                System.out.print(temp[i][j] + "F ");
	            }

	            
	            boolean fever = false;
	            for (int j = 0; j < days; j++) {
	                if (temp[i][j] >= 100.4) {
	                    fever = true;
	                }
	            }

	            if (fever) {
	                System.out.println(" | FEVER - Continue Treatment");
	            } else {
	                System.out.println(" | NORMAL - No Treatment");
	            }
	        }
	        sc.close();
	    }
	}


