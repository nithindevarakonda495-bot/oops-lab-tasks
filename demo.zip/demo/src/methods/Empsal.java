package methods;
import java.util.*;
public class Empsal {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        
	        System.out.print("Enter number of employees: ");
	        int n = sc.nextInt();
	        sc.nextLine();

	        String[] names = new String[n];
	        double[] salaries = new double[n];

	        
	        for (int i = 0; i < n; i++) {
	            System.out.print("\nEnter Name of Employee " + (i+1) + ": ");
	            names[i] = sc.nextLine();
	            System.out.print("Enter Salary for " + names[i] + ": ");
	            salaries[i] = sc.nextDouble();
	            sc.nextLine();
	        }

	       
	        int highestIndex = 0;
	        int lowestIndex = 0;
	        for (int i = 1; i < n; i++) {
	            if (salaries[i] > salaries[highestIndex]) highestIndex = i;
	            if (salaries[i] < salaries[lowestIndex]) lowestIndex = i;
	        }

	        
	        System.out.println("\n===== EMPLOYEE REPORT =====");
	        for (int i = 0; i < n; i++) {
	            System.out.println(names[i] + " - Salary: " + salaries[i]);
	        }

	        System.out.println("\n--- HIGHEST PAID EMPLOYEE ---");
	        System.out.println("Name: " + names[highestIndex] + " | Salary: " + salaries[highestIndex]);

	        System.out.println("\n--- LOWEST PAID EMPLOYEE ---");
	        System.out.println("Name: " + names[lowestIndex] + " | Salary: " + salaries[lowestIndex]);

	        sc.close();
	    }
	}

