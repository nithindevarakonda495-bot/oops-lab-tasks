package methods;
import java.util.*;

	public class StudentResultSystem {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter number of students: ");
	        int students = sc.nextInt();
	        System.out.print("Enter number of subjects: ");
	        int subjects = sc.nextInt();
	        sc.nextLine();

	        String[] names = new String[students];
	        int[][] marks = new int[students][subjects];
	        int[] totals = new int[students];
	        double[] averages = new double[students];
	        char[] grades = new char[students];

	     
	        for (int i = 0; i < students; i++) {
	            System.out.print("\nEnter Name of Student " + (i + 1) + ": ");
	            names[i] = sc.nextLine();

	            System.out.println("Enter marks for " + names[i]);
	            int total = 0;
	            for (int j = 0; j < subjects; j++) {
	                while (true) {
	                    System.out.print("Subject " + (j + 1) + ": ");
	                    int mark = sc.nextInt();
	                    if (mark >= 0 && mark <= 100) {
	                        marks[i][j] = mark;
	                        total += mark;
	                        break;
	                    } else {
	                        System.out.println("Invalid! Enter marks between 0 and 100.");
	                    }
	                }
	            }
	            sc.nextLine();
	            totals[i] = total;
	            averages[i] = total / (double) subjects;

	            if (averages[i] >= 90) grades[i] = 'A';
	            else if (averages[i] >= 75) grades[i] = 'B';
	            else if (averages[i] >= 60) grades[i] = 'C';
	            else if (averages[i] >= 50) grades[i] = 'D';
	            else grades[i] = 'F';
	        }

	       
	        int topperIndex = 0;
	        int leastIndex = 0;
	        for (int i = 1; i < students; i++) {
	            if (totals[i] > totals[topperIndex]) topperIndex = i;
	            if (totals[i] < totals[leastIndex]) leastIndex = i;
	        }

	     
	        System.out.println("\n===== FINAL REPORT =====");
	        System.out.print("Name\t");
	        for (int j = 0; j < subjects; j++) System.out.print("Sub" + (j+1) + "\t");
	        System.out.println("Total\tAvg\tGrade");

	        for (int i = 0; i < students; i++) {
	            System.out.print(names[i] + "\t");
	            for (int j = 0; j < subjects; j++) System.out.print(marks[i][j] + "\t");
	            System.out.println(totals[i] + "\t" + averages[i] + "\t" + grades[i]);
	        }

	        System.out.println("\n--- TOPPER ---");
	        System.out.println("Name: " + names[topperIndex] + ", Total: " + totals[topperIndex] + ", Avg: " + averages[topperIndex] + ", Grade: " + grades[topperIndex]);

	        System.out.println("\n--- LEAST RANKER ---");
	        System.out.println("Name: " + names[leastIndex] + ", Total: " + totals[leastIndex] + ", Avg: " + averages[leastIndex] + ", Grade: " + grades[leastIndex]);

	        sc.close();
	    }
	}


